
public class T4_TalentsAchievements extends T3_Hobby {
	//Subclass - Texts used in Education and Skills
	String talent1 = "Cooking";
	String talent2 = "Video Editing";
	String achievement1 = "<html><center>First Place</center><center>Short Horror Film</center><center>(JHS)</center></html>";
	String achievement2 = "<html><center>Graduated</center><center>with Honors</center></html>";
}
