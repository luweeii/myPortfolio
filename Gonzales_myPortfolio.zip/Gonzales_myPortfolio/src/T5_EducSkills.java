
public class T5_EducSkills extends T4_TalentsAchievements {
	String jhs = "<html><b>Junior High School</b></html>";
	String jhsYear_School = "<html><ul>" +
						"<b>2020 - 2022</b>" +
						"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Colegio de San Bartolome de &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Novaliches</br></ul></html>";
	
	String shs = "<html><b>Senior High School</b></html>";
	String shsYear_School = "<html><ul>" +
			"<b>2016 - 2020</b>" +
			"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;STI College Novaliches (STEM)</br></ul></html>";
	
	String college = "<html><b>College</b></html>";
	String collegeYear_School = "<html><ul>" +
			"<b>2022 - Present</b>" +
			"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;National University - Manila</br>" +
			"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;BSIT - Mobile and Web Application</br></ul></html>";
	
	String adobePP = "Adobe Premiere Pro";
	String adobeLR = "Adobe Lightroom";
	String photoSkill = "Photography";
	String videoSkill = "Videography";
}
