
public class T1_LandingPage {
	
	//Parent Class - Texts used in Landing Page Frame
	String summary = "<html><div style='text-align: justify;'>Hello, I'm Patrick Louie Gonzales and this is my portfolio which consists of my Basic Information, Hobbies, Talents & Achievements, Educational Background, and Skills. Just click the buttons below and you can reach out to me with my contact number, email, Facebook, and Instagram as listed below:</div></html>";
	String contact = "<html><b>Contact No.</b> 09062046250</html>";
	String email = "<html><b>Email: </b>plouiegon@gmail.com</html>";
	String fb = "<html><b>Facebook: </b>Patrick Louie Gonzales</html>";
	String ig = "<html><b>Instagram: </b>p.luweeii</html>";
}
