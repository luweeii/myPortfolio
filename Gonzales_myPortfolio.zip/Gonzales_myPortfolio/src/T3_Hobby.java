
public class T3_Hobby extends T2_BasicInformation{
	//Subclass - Texts used in Talents and Achievements
	String hobby1 = "Cycling";
	String hobby2 = "Photography";
	String hobby3 = "Playing Video Games";
}
