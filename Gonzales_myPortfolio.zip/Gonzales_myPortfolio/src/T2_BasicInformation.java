
public class T2_BasicInformation extends T1_LandingPage {
	//Subclass - Texts used in Basic Information Frame
	String basicInfo = 
				"<html><ul>" +
				"<li><b>Name: </b>Patrick Louie P. Gonzales</li>" +
				"<li><b>Sex: </b>Male</li>" +
				"<li><b>Birthdate: </b>February 03, 2004</li>" +
				"<li><b>Age: </b>19</li>" +
				"<li><b>School: </b>National University - Manila</li>" +
				"<li><b>Course: </b>BSIT - Mobile and Web Application</li>" +
				"<li><b>Hair Color: </b>Black</li>" +
				"<li><b>Strenghts: </b></li>" +
				"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Handles pressure well" +
				"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Works well with a team</br>" +
				"<li><b>Weaknesses: </b></li>" +
				"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Low self esteem" +
				"<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Peer pressure</br></html>";
}
